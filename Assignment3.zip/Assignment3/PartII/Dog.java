public class Dog {
        private int age;
        private String owner;
        private String breed;
        // a. Default Constructor
        public Dog() {
                this.age = 0;
                this.owner = "";
                this.breed = "";
        }

        // a. Constructor
        public Dog(int age, String owner, String breed) {
                this.age = age;
                this.owner = owner;
                this.breed = breed;
        }

        // b.Static method to check if two dogs have the same owner
        public static boolean hasSameOwner(Dog dog1, Dog dog2) {
                return dog1.getOwner().equals(dog2.getOwner());
        }

        // c. Static method to calculate the average age of an array of dogs
        public static double avgAge(Dog[] dogs) {
                int totalAge = 0;
                for (Dog dog : dogs) {
                totalAge += dog.getAge();
                }
                return (double) totalAge / dogs.length;
        }

        // d. Getter methods
        public int getAge() {
                return age;
        }

        public String getOwner() {
                return owner;
        }

        public String getBreed() {
                return breed;
        }

        // d. Setter methods
        public void setAge(int age) {
                this.age = age;
        }

        public void setOwner(String owner) {
                this.owner = owner;
        }

        public void setBreed(String breed) {
                this.breed = breed;
        }

        // e. toString method
        @Override
        public String toString() {
                return breed + ": Owner: " + owner + ", Age: " + age;
        }


        public static void main(String[] args) {

                //  You may assume that the array is full 
                // (i.e. does not have any null entries). 
                // Show how it is used
                Dog[] dogs = new Dog[3];
                dogs[0] = new Dog(4, "Stephen Colbert", "Boxer");
                dogs[1] = new Dog(2, "Stephen Colbert", "Poodle");
                dogs[2] = new Dog(3, "Stephen Colbert", "Pug");

                System.out.println("Age: " + dogs[0].getAge());
                System.out.println("Owner: " + dogs[0].getOwner());
                System.out.println("Breed: " + dogs[0].getBreed());

                System.out.println("Dog1 and Dog2 have the same owner: " + Dog.hasSameOwner(dogs[0], dogs[1]));
                System.out.println("Dog1 and Dog3 have the same owner: " + Dog.hasSameOwner(dogs[1], dogs[2]));

                double averageAge = Dog.avgAge(dogs);
                System.out.println("Average Age of Dogs: " + averageAge);

                System.out.println("Age: " + dogs[0].getAge());
                System.out.println("Owner: " + dogs[0].getOwner());
                System.out.println("Breed: " + dogs[0].getBreed());

                dogs[0].setAge(4);
                dogs[0].setOwner("Alice");
                dogs[0].setBreed("Labrador");

                System.out.println("\nUpdated Age: " + dogs[0].getAge());
                System.out.println("Updated Owner: " + dogs[0].getOwner());
                System.out.println("Updated Breed: " + dogs[0].getBreed());

                System.out.println("\nDog 1: " + dogs[0].toString());

                Dog myDog = new Dog(8, "Dexter Morgan", "Corgi");
                System.out.println(myDog.toString());
        }

}



