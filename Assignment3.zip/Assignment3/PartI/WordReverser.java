
public class WordReverser {

	public static String reverseSentence(String sentence) {
		// reverseSentence, input is a String, output is a String
		// reverseSentence takes a sentence and returns a new sentence
		// with the words in reverse order
		// eg, "The quick brown fox" -> "fox brown quick The"

		// split the sentence into words
		String[] words = sentence.split(" ");
		// create a new array of the same length
		String[] reversedWords = new String[words.length];
		// loop through the words in the original array
		for (int i = 0; i < words.length; i++) {
			// put the words in the new array in reverse order
			reversedWords[i] = words[words.length - 1 - i];
		}
		// join the words in the new array into a sentence
		String reversedSentence = String.join(" ", reversedWords);
		// return the sentence
		return reversedSentence;
		
		return null;
	}
	
	public static void main(String[] args) {
		String result = reverseSentence("The quick brown fox jumps over the lazy dog");

	}

}
