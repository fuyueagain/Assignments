public class Account {
    private static int idCounter = 1;
    private int id;
    private double balance;
    
    // Default Constructor
    public Account() {
        this.id = idCounter++;
        this.balance = 0.0;
    }

    public Account(double startingBalance) {
        this.id = idCounter++;
        this.balance = startingBalance;
    }

    public boolean withdraw(double amount) {
        if (amount >= 0 && balance >= amount) {
            balance -= amount;
            return true;
        } else {
            return false;
        }
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount >= 0) {
            balance += amount;
        }
    }
    
    public int getId() {
        return id;
    }

}

