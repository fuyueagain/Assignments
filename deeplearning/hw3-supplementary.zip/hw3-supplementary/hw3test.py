from scipy.linalg import eigh
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable

def load_and_center_dataset(filename):
    # over 2414 arrays of 1024 floats
    x = np.load(filename)
    x = x.astype(np.float64)
    x = x - np.mean(x, axis=0)
    return x



def get_covariance(dataset):
    xT = np.array(dataset) # row vectors is 2414*1024
    x = np.transpose(xT) #column vectors is 1024*2414
    res = np.dot(x, xT) #column . row = matrix, 1024*1024
    res = res / (len(xT) - 1)
    return res


def get_eig(S, m):
    # return the first m eigenvalues and corresponding eigenvectors
    eigenvalues, eigenvectors = eigh(S, subset_by_index=[len(S)-m, len(S)-1])
    eigenvalues = np.flip(eigenvalues)
    eigenvectors = np.flip(eigenvectors, axis=1)
    return np.diag(eigenvalues), eigenvectors



def get_eig_prop(S, prop):
    eigenvalues, eigenvectors = eigh(S, subset_by_index=[0, len(S) - 1])# asending order
    eigenvalues = np.flip(eigenvalues)# convert to descending order
    eigenvectors = np.flip(eigenvectors, axis=1)# convert to descending order
    
    sum = np.sum(eigenvalues)

    for i in range(len(eigenvalues)):
        i_prop = eigenvalues[i] / sum
        if i_prop <= prop:
            return np.diag(eigenvalues[:i]), eigenvectors[:, :i]
        
    return np.diag(eigenvalues), eigenvectors


def project_image(image, U):
    # input is 1024*1, output is 1024*1
    projection = np.dot(np.transpose(U), image)
    pca_value = np.dot(U, projection)
    return pca_value

    

def display_image(orig, proj):
    orig = orig.reshape(32, 32)
    proj = proj.reshape(32, 32)
    
    orig = np.rot90(orig, k=3)
    proj = np.rot90(proj, k=3)
    fig, (ax1, ax2) = plt.subplots(1, 2)
  
    ax1.set_title('Original')
    ax2.set_title('Projection')

    # Use the return value of imshow to create a colorbar for each image.
    # fig.colorbar(ax1.imshow(orig, aspect='equal'),  ax=ax1, fraction=0.046, orientation='vertical')
    # fig.colorbar(ax2.imshow(proj, aspect='equal'), ax=ax2, fraction=0.046, orientation='vertical')

    im1 = ax1.imshow(orig, aspect='equal')
    im2 = ax2.imshow(proj, aspect='equal')

    divider1 = make_axes_locatable(ax1)
    divider2 = make_axes_locatable(ax2)
    cax1 = divider1.append_axes("right",  pad=0.05)
    cax2 = divider2.append_axes("right", pad=0.05)

    cbar1 = fig.colorbar(im1, cax=cax1, orientation='vertical')
    cbar2 = fig.colorbar(im2, cax=cax2, orientation='vertical')

    return fig, ax1, ax2


# test  
def main(args=None):
    x = load_and_center_dataset('YaleB_32x32.npy')
    S = get_covariance(x)
    Lambda, U = get_eig(S, 2)
    print(Lambda)
    print(U)
    # Lambda1, U1 = get_eig_prop(S, 0.07)
    # print(Lambda1)
    # print(U1)
    projection = project_image(x[0], U)
    print(projection)
    fig, (ax1, ax2) = display_image(x[0], projection)
    plt.show()

if __name__ == '__main__':
    main()

