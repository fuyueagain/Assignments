import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage


def load_data(filepath):
# Input: string, the path to a file to be read.
# Output: list, where each element is a dict representing one row of the file read.
    output = []
    with open(filepath, encoding="UTF8") as csvfile:
        countries = csv.DictReader(csvfile)
        for aRow in countries:
            output.append(aRow)

    return output




def calc_features(row):
# Input: dict representing one country.
# Output: NumPy array of shape (6,) and dtype float64. The first element is x1 and so
# on with the sixth element being x6
    x1 = row["Population"]
    x2 = row["Net migration"]
    x3 = row["GDP ($ per capita)"]
    x4 = row["Literacy (%)"]
    x5 = row["Phones (per 1000)"]
    x6 = row["Infant mortality (per 1000 births)"]
    output = np.array([x1, x2, x3, x4, x5, x6], dtype=np.float64)
    return output




def hac(features):
# Input: list of NumPy arrays of shape (6,),the length of the input list, is n. 
# Output: numpy array of shape (n − 1) × 4. 
    n = len(features)
    distMatrix = np.zeros(shape=(n, n))
    marker = dict()

    for i in range(n):
            marker[i] = [i]   
            # 0 - n-1, label every feature 

    for i in range(n):  
        # Euclidean distance
        for j in range(n):
            if i == j:
                continue
            distMatrix[i][j] = np.linalg.norm(features[i] - features[j])

    resZ = np.empty([0, 4])
    index = n

    for iter in range(n - 1):
        # initialize
        minV = float('inf')
        z0 = 0
        z1 = 0

        for i in marker: 
            for j in marker: 
                if i == j:
                    continue
                #different clusters
                iCluster = marker[i]  
                jCluster = marker[j]  
                # initialize
                maxV = float('-inf')
                for ti in iCluster:  
                    for tj in jCluster:  
                        if maxV < distMatrix[ti][tj]: 
                            maxV = distMatrix[ti][tj]
                            # find max distance
                if maxV == minV:
                    if z0 > i:
                        z0 = i
                        z1 = j
                    elif z0 == i:
                        if z1 > j:
                            z1 = j
                elif minV > maxV:  
                    minV = maxV
                    # find min distance
                    z0 = i 
                    z1 = j  
                    # mark
                

        marker[index] = marker[z0] + marker[z1] 
        
        # delete old clusters
        del marker[z0]
        del marker[z1]

        resZ = np.vstack((resZ, [z0, z1, minV, len(marker[index])])) 
        # vertically stack
        index += 1
    return resZ

  
def fig_hac(Z, names):
# Input: NumPy array Z output from hac, and list of string names corresponding to
# country names with length n.
# Output: A matplotlib figure with a graph that visualizes the hierarchical clustering.  
    fig = plt.figure()
    dendrogram(Z, labels=names, leaf_rotation=90)
    plt.tight_layout()
    return fig


def normalize_features(features):
# Input: calc_features- a NumPy array with shape (6,) and dtype float64.
# Output: a list of NumPy arrays with shape (6,) and dtype float64. 
# Normalize: subtract the column’s mean from the value and 
# divide the result by the column’s standard deviation.
    features = np.array(features)
    mean = np.mean(features, axis=0)
    std = np.std(features, axis=0)
    normalFeatures = (features - mean) / std
    return normalFeatures


def main():
    data = load_data("countries.csv")
    country_names = [row["Country"] for row in data]
    features = [calc_features(row) for row in data]
    features_normalized = normalize_features(features)
    n = 50
    Z_raw = hac(features[:n])
    Z_normalized = hac(features_normalized[:n])
    # print(Z_raw)
    print(Z_normalized)
    fig1 = fig_hac(Z_raw, country_names[:n])
    fig2 = fig_hac(Z_normalized, country_names[:n])
    # add N = 15 to the figure
    # fig1.suptitle("N = %d" % n)
    # fig2.suptitle("N = %d" % n)

    # plt.show()

if __name__=="__main__":
    main()
