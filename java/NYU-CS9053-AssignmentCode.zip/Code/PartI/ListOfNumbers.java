import java.io.*;
import java.util.List;
import java.util.ArrayList;
import shapes.*;



public class ListOfNumbers {
	
    private ArrayList rdfTripleList;
    
    private String fileName;
 
    public ListOfNumbers () {
        // create an ArrayList of Pairs of Integers
        this.rdfTripleList = new ArrayList<RDFTriple<Integer, Integer, Integer>>();
    }
    
    public ArrayList getRdfTripleList() {
    	return this.rdfTripleList;
    }
    
    public void createList() {
    	for (int i = 0 ; i< 100 ; i++) {
    		Integer number1 = (int) (Math.random()*10000);
    		Integer number2 = (int) (Math.random()*10000);
    		Integer number3 = (int) (Math.random()*10000);
    		// fill the existing list with RDFTriple objects
    		// of three numbers.
            this.rdfTripleList.add(new RDFTriple<Integer, Integer, Integer>(number1, number2, number3));

    	}
    }
    

    public ListOfNumbers (String fileName) {
    	this();
    	this.fileName = fileName;	
    }


    public void readList() {

        FileReader fr = null;
        try {
            fr = new FileReader(this.fileName);
            BufferedReader br = new BufferedReader(fr);
            String linea = null;
            linea = br.readLine();
            while (linea != null) {
            	String[] triple = linea.split(" ");
            	Integer number1 = Integer.parseInt(triple[0]);
            	Integer number2 = Integer.parseInt(triple[1]);
            	Integer number3 = Integer.parseInt(triple[2]);
            	// fill the existing list with RDFTriple objects
            	// of three numbers.
                this.rdfTripleList.add(new RDFTriple<Integer, Integer, Integer>(number1, number2, number3));
                linea = br.readLine();
            }
            System.out.println("File read successfully");
        }catch (FileNotFoundException fne) {
            System.out.println("File not found error: "+ fne.getMessage());
            System.exit(1);
        } catch (IOException ioe) {
            
            System.out.println("IO reading file error: " + ioe.getMessage());

        } catch (ArrayIndexOutOfBoundsException aioobe) {

            System.out.println("array index out of bounds error");

        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException ioe) {
                    System.out.println("closing file error: "+ ioe.getMessage());
                } 
            }
        }
    	
    }
    
   public void writeList() {
       PrintWriter out = null;
       try {
           System.out.println("Entering try statement");
           out = new PrintWriter(new FileWriter(this.fileName));
           for (int i = 0; i < rdfTripleList.size(); i++) {
            Object obj = rdfTripleList.get(i);
            if (obj instanceof RDFTriple) {
                RDFTriple<Integer, Integer, Integer> triple = (RDFTriple<Integer, Integer, Integer>) obj;
                out.println(triple.getSubj() + " " + triple.getPred() + " " + triple.getObj());
            }
        }
        //    for (int i = 0; i < rdfTripleList.size(); i++)
        //        out.println(rdfTripleList.get(i).getSubj() + " " + rdfTripleList.get(i).getPred()+ " " + rdfTripleList.get(i).getObj());
       } catch (IndexOutOfBoundsException e) {
           System.err.println("Caught IndexOutOfBoundsException: " +
                                e.getMessage());
       } catch (IOException e) {
           System.err.println("Caught IOException: " + e.getMessage());
       } finally {
           if (out != null) {
               System.out.println("Closing PrintWriter");
               out.close();
           } else {
               System.out.println("PrintWriter not open");
           }
       }
   }
    
//    public static void cat(String fileName) {
//        RandomAccessFile input = null;
//        String line = null;
//        File file = new File(fileName);
//        try {
//            input = new RandomAccessFile(file, "r");
//            while ((line = input.readLine()) != null) {
//                System.out.println(line);
//            }
//            return;
//        } finally {
//            if (input != null) {
//                input.close();
//            }
//        }
//    }
   public static void cat(String fileName) {
    RandomAccessFile input = null;
    String line = null;
    File file = new File(fileName);
    try {
        input = new RandomAccessFile(file, "r");
        while ((line = input.readLine()) != null) {
            System.out.println(line);
        }
        return;
    } catch (FileNotFoundException e) {
        System.err.println("FileNotFoundException: " + e.getMessage());
    } catch (IOException e) {
        System.err.println("IOException: " + e.getMessage());
    } finally {
        if (input != null) {
            try {
                input.close();
            } catch (IOException e) {
                System.err.println("IOException while closing input: " + e.getMessage());
            }
        }
    }
}
    
    public static void main(String[] args) {
    	ListOfNumbers listOfNumbers = new ListOfNumbers("numberfile.txt");
   	    ListOfNumbers.cat("numberfile.txt");
    	listOfNumbers.readList();
   	    listOfNumbers.writeList();
    }

}
