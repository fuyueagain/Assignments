import java.io.*;
import java.util.ArrayList;
import shapes.*;
import shapes.ShapeException;

/* your tasks:
 * create a class called ShapeException
 * createShape should throw a ShapeException
 * in main(), you should catch the ShapeException
 * 
 */
public class ReadShapeFile {

	public static GeometricObject createShape(String shape) throws ShapeException{
		
		/* if vehicleName is "Circle" return Circle();
		 * if vehicleName is "Rectangle" return Rectangle();
		 * if vehicleName is "Square" return Square();
		 * if it is not any one of these, it should throw
		 * a ShapeException
		 */
		if (shape.equals("Circle")) {
			return new Circle();
		} else if (shape.equals("Rectangle")) {
			return new Rectangle();
		} else if (shape.equals("Square")) {
			return new Square();
		}else {
			throw new ShapeException(shape);
		}

		
	}
	
	public static void main(String[] args) {
		ArrayList<GeometricObject> shapeList = new ArrayList<GeometricObject>();
		File f = new File("shapes.txt");
		
		String inString = null;
		
		/* create a loop to read the file line-by-line */
		
	
		FileReader freader = null;
		try {
			freader = new FileReader(f);
		} catch (FileNotFoundException fne) {

			System.out.println("File not found: "+ fne.getMessage());
			System.exit(1);
		}

		BufferedReader in = new BufferedReader(freader);
		String aline = null;
		try {
			aline = in.readLine();
			while (aline != null) {
				inString = aline;
				try {
					GeometricObject shape = createShape(inString);
					shapeList.add(shape);
				} catch (ShapeException se) {
					System.err.println("Cannot create shape: " + inString);
					System.err.println("ShapeException error: " + se.getMessage());
				}
				finally {
					aline = in.readLine();
				}
			}

		} catch (IOException ioe) {
			System.out.println("IO reading file error: " + ioe.getMessage());
		} finally {
			if (freader != null) {
				try {
					freader.close();
				} catch (IOException e) {
					System.out.println("closing file error: "+ e.getMessage());
				} 
			}
		}

		System.out.println(shapeList);
		
	}
}
